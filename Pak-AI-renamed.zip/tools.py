# tools.py – AI Logic will be pasted here manually
