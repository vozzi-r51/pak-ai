# Pak AI

Run `streamlit run streamlit_app.py` to launch.
