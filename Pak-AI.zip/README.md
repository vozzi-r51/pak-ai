# Pak AI

Run `streamlit run app.py` to launch.
